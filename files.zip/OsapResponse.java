package com.prospecto.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * OsapResponse — JSON response body for POST /api/osap-gap
 * Mirrors Flask jsonify({
 *   "total_cost": X, "osap_loan": X, "remaining_balance": X,
 *   "gap_scholarships": [...], "total_available": X
 * })
 */
public class OsapResponse {

    @JsonProperty("total_cost")
    private double totalCost;

    @JsonProperty("osap_loan")
    private double osapLoan;

    @JsonProperty("remaining_balance")
    private double remainingBalance;

    @JsonProperty("gap_scholarships")
    private List<Scholarship> gapScholarships;

    @JsonProperty("total_available")
    private double totalAvailable;

    public OsapResponse() {}

    public OsapResponse(double totalCost, double osapLoan, double remainingBalance,
                        List<Scholarship> gapScholarships, double totalAvailable) {
        this.totalCost         = totalCost;
        this.osapLoan          = osapLoan;
        this.remainingBalance  = remainingBalance;
        this.gapScholarships   = gapScholarships;
        this.totalAvailable    = totalAvailable;
    }

    public double getTotalCost()                        { return totalCost; }
    public void setTotalCost(double totalCost)          { this.totalCost = totalCost; }

    public double getOsapLoan()                         { return osapLoan; }
    public void setOsapLoan(double osapLoan)            { this.osapLoan = osapLoan; }

    public double getRemainingBalance()                 { return remainingBalance; }
    public void setRemainingBalance(double rb)          { this.remainingBalance = rb; }

    public List<Scholarship> getGapScholarships()       { return gapScholarships; }
    public void setGapScholarships(List<Scholarship> g) { this.gapScholarships = g; }

    public double getTotalAvailable()                   { return totalAvailable; }
    public void setTotalAvailable(double ta)            { this.totalAvailable = ta; }
}
