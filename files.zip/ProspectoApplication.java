package com.prospecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Prospecto — Canadian Scholarship Matching App
 * Java Spring Boot backend (converted from Python Flask)
 *
 * Run:  mvn spring-boot:run
 * Open: http://localhost:8080
 */
@SpringBootApplication
public class ProspectoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProspectoApplication.class, args);
    }
}
