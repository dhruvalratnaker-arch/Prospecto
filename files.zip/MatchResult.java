package com.prospecto.model;

import java.util.List;

/**
 * MatchResult — internal transfer object returned by
 * ScholarshipService.calculateMatchScore().
 *
 * Not serialised to JSON directly; data is copied onto the Scholarship object.
 */
public class MatchResult {

    private final int score;
    private final List<String> reasons;
    private final ScoreBreakdown breakdown;

    public MatchResult(int score, List<String> reasons, ScoreBreakdown breakdown) {
        this.score     = score;
        this.reasons   = reasons;
        this.breakdown = breakdown;
    }

    public int getScore()                { return score; }
    public List<String> getReasons()     { return reasons; }
    public ScoreBreakdown getBreakdown() { return breakdown; }
}
