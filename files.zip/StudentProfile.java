package com.prospecto.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * StudentProfile — the JSON body sent to POST /api/match.
 *
 * Mirrors the Python Flask request.json dict:
 * { gpa, income, ethnicity, interests, major, tuition, osap_loan }
 */
public class StudentProfile {

    private String gpa;
    private String income;
    private String ethnicity;
    private String interests;
    private String major;
    private String tuition;

    @JsonProperty("osap_loan")
    private String osapLoan;

    // ── Convenience numeric accessors ─────────────────────────────────

    /** Parse GPA safely, returning 0.0 on blank/null */
    public double getGpaDouble() {
        try { return gpa != null && !gpa.isBlank() ? Double.parseDouble(gpa) : 0.0; }
        catch (NumberFormatException e) { return 0.0; }
    }

    /** Parse income safely */
    public double getIncomeDouble() {
        try { return income != null && !income.isBlank() ? Double.parseDouble(income) : 0.0; }
        catch (NumberFormatException e) { return 0.0; }
    }

    /** Parse tuition safely */
    public double getTuitionDouble() {
        try { return tuition != null && !tuition.isBlank() ? Double.parseDouble(tuition) : 0.0; }
        catch (NumberFormatException e) { return 0.0; }
    }

    /** Parse OSAP loan safely */
    public double getOsapLoanDouble() {
        try { return osapLoan != null && !osapLoan.isBlank() ? Double.parseDouble(osapLoan) : 0.0; }
        catch (NumberFormatException e) { return 0.0; }
    }

    // ── Standard Getters/Setters ───────────────────────────────────────

    public String getGpa()                      { return gpa; }
    public void setGpa(String gpa)              { this.gpa = gpa; }

    public String getIncome()                   { return income; }
    public void setIncome(String income)        { this.income = income; }

    public String getEthnicity()                { return ethnicity != null ? ethnicity : ""; }
    public void setEthnicity(String e)          { this.ethnicity = e; }

    public String getInterests()                { return interests != null ? interests : ""; }
    public void setInterests(String i)          { this.interests = i; }

    public String getMajor()                    { return major != null ? major : ""; }
    public void setMajor(String major)          { this.major = major; }

    public String getTuition()                  { return tuition; }
    public void setTuition(String tuition)      { this.tuition = tuition; }

    public String getOsapLoan()                 { return osapLoan; }
    public void setOsapLoan(String osapLoan)    { this.osapLoan = osapLoan; }
}
