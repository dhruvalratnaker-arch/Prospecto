package com.prospecto.controller;

import com.prospecto.model.*;
import com.prospecto.service.ScholarshipService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

/**
 * ApiController
 *
 * REST API endpoints consumed by the frontend JavaScript (fetch calls).
 * All responses are JSON — Spring Boot's @RestController handles serialisation
 * automatically via Jackson.
 *
 * Equivalent Flask routes:
 *   POST /api/match         → api_match()
 *   POST /api/osap-gap      → api_osap_gap()
 *   GET  /api/scholarships  → api_all_scholarships()
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    private final ScholarshipService service;

    // Spring injects ScholarshipService via constructor injection
    public ApiController(ScholarshipService service) {
        this.service = service;
    }

    // ── POST /api/match ────────────────────────────────────────────────────
    /**
     * Receives a student profile, runs the matching engine, and returns
     * scored + sorted scholarships along with the tuition gap.
     *
     * Request body:  { gpa, income, ethnicity, interests, major, tuition, osap_loan }
     * Response:      { matches: [...], tuition_gap: X, total_scholarships: N }
     *
     * Equivalent Python:
     *   @app.route("/api/match", methods=["POST"])
     *   def api_match():
     *       matches = filter_scholarships(request.json)
     *       gap = max(0, tuition - osap_loan)
     *       return jsonify({"matches": matches, "tuition_gap": gap, ...})
     */
    @PostMapping("/match")
    public ResponseEntity<?> match(@RequestBody StudentProfile student) {
        try {
            List<Scholarship> matches = service.filterScholarships(student);

            // Calculate simple tuition gap (tuition - osap loan)
            double tuition  = student.getTuitionDouble();
            double osapLoan = student.getOsapLoanDouble();
            double gap      = Math.max(0, tuition - osapLoan);

            MatchResponse response = new MatchResponse(matches, gap);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body("Error loading scholarships: " + e.getMessage());
        }
    }

    // ── POST /api/osap-gap ─────────────────────────────────────────────────
    /**
     * Calculates total education cost, OSAP coverage, remaining balance, and
     * returns scholarships that can help fill the gap.
     *
     * Request body:  { tuition, residence, books, osap_loan }
     * Response:      { total_cost, osap_loan, remaining_balance,
     *                  gap_scholarships: [...], total_available }
     *
     * Equivalent Python:
     *   @app.route("/api/osap-gap", methods=["POST"])
     *   def api_osap_gap():
     *       total_cost, remaining = calculate_osap_gap(...)
     *       gap_scholarships = filter_scholarships_for_gap(remaining)
     *       return jsonify({...})
     */
    @PostMapping("/osap-gap")
    public ResponseEntity<?> osapGap(@RequestBody OsapRequest req) {
        try {
            // Step 1: Calculate the gap
            double[] gap = service.calculateOsapGap(
                req.getTuition(), req.getResidence(),
                req.getBooks(),   req.getOsapLoan()
            );
            double totalCost        = gap[0];
            double remainingBalance = gap[1];

            // Step 2: Find scholarships that cover the gap
            List<Scholarship> gapScholarships =
                service.filterScholarshipsForGap(remainingBalance);

            // Step 3: Sum the total available award money
            double totalAvailable = gapScholarships.stream()
                .mapToDouble(Scholarship::getAmount)
                .sum();

            OsapResponse response = new OsapResponse(
                totalCost, req.getOsapLoan(), remainingBalance,
                gapScholarships, totalAvailable
            );
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body("Error loading scholarships: " + e.getMessage());
        }
    }

    // ── GET /api/scholarships ──────────────────────────────────────────────
    /**
     * Returns all scholarships sorted by deadline — used by the Roadmap page.
     *
     * Equivalent Python:
     *   @app.route("/api/scholarships", methods=["GET"])
     *   def api_all_scholarships():
     *       scholarships.sort(key=lambda x: x["deadline"])
     *       return jsonify(scholarships)
     */
    @GetMapping("/scholarships")
    public ResponseEntity<?> allScholarships() {
        try {
            List<Scholarship> scholarships = service.getAllScholarshipsByDeadline();
            return ResponseEntity.ok(scholarships);
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body("Error loading scholarships: " + e.getMessage());
        }
    }
}
