package com.prospecto.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * MatchResponse — JSON response body for POST /api/match
 * Mirrors Flask jsonify({ "matches": [...], "tuition_gap": X, "total_scholarships": N })
 */
public class MatchResponse {

    private List<Scholarship> matches;

    @JsonProperty("tuition_gap")
    private double tuitionGap;

    @JsonProperty("total_scholarships")
    private int totalScholarships;

    public MatchResponse() {}

    public MatchResponse(List<Scholarship> matches, double tuitionGap) {
        this.matches           = matches;
        this.tuitionGap        = tuitionGap;
        this.totalScholarships = matches.size();
    }

    public List<Scholarship> getMatches()             { return matches; }
    public void setMatches(List<Scholarship> matches) { this.matches = matches; }

    public double getTuitionGap()                     { return tuitionGap; }
    public void setTuitionGap(double tuitionGap)      { this.tuitionGap = tuitionGap; }

    public int getTotalScholarships()                 { return totalScholarships; }
    public void setTotalScholarships(int n)           { this.totalScholarships = n; }
}
