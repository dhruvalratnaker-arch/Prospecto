package com.prospecto.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * OsapRequest — JSON body for POST /api/osap-gap
 * { tuition, residence, books, osap_loan }
 */
public class OsapRequest {

    private double tuition;
    private double residence;
    private double books;

    @JsonProperty("osap_loan")
    private double osapLoan;

    public double getTuition()                  { return tuition; }
    public void setTuition(double tuition)      { this.tuition = tuition; }

    public double getResidence()                { return residence; }
    public void setResidence(double residence)  { this.residence = residence; }

    public double getBooks()                    { return books; }
    public void setBooks(double books)          { this.books = books; }

    public double getOsapLoan()                 { return osapLoan; }
    public void setOsapLoan(double osapLoan)    { this.osapLoan = osapLoan; }
}
