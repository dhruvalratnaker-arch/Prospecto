package com.prospecto.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Scholarship — represents one scholarship record from scholarships.json.
 *
 * Jackson uses @JsonProperty to map snake_case JSON keys to camelCase
 * Java fields automatically.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Scholarship {

    // ── Core Fields (from scholarships.json) ──────────────────────────

    private int id;
    private String name;
    private int amount;
    private String deadline;

    @JsonProperty("min_gpa")
    private double minGpa;

    @JsonProperty("income_limit")
    private double incomeLimit;

    @JsonProperty("fields_of_study")
    private List<String> fieldsOfStudy;

    private String description;

    @JsonProperty("eligibility_requirements")
    private String eligibilityRequirements;

    @JsonProperty("required_actions")
    private List<String> requiredActions;

    @JsonProperty("ethnicity_bonus")
    private List<String> ethnicityBonus;

    @JsonProperty("extracurricular_bonus")
    private List<String> extracurricularBonus;

    // ── Match Score Fields (populated after scoring) ──────────────────
    // These are null when the object is loaded raw from JSON

    @JsonProperty("match_score")
    private Integer matchScore;

    @JsonProperty("match_reasons")
    private List<String> matchReasons;

    @JsonProperty("score_breakdown")
    private ScoreBreakdown scoreBreakdown;

    // ── Constructors ──────────────────────────────────────────────────

    public Scholarship() {}

    // ── Getters & Setters ─────────────────────────────────────────────

    public int getId()                              { return id; }
    public void setId(int id)                       { this.id = id; }

    public String getName()                         { return name; }
    public void setName(String name)                { this.name = name; }

    public int getAmount()                          { return amount; }
    public void setAmount(int amount)               { this.amount = amount; }

    public String getDeadline()                     { return deadline; }
    public void setDeadline(String deadline)        { this.deadline = deadline; }

    public double getMinGpa()                       { return minGpa; }
    public void setMinGpa(double minGpa)            { this.minGpa = minGpa; }

    public double getIncomeLimit()                  { return incomeLimit; }
    public void setIncomeLimit(double incomeLimit)  { this.incomeLimit = incomeLimit; }

    public List<String> getFieldsOfStudy()          { return fieldsOfStudy; }
    public void setFieldsOfStudy(List<String> f)    { this.fieldsOfStudy = f; }

    public String getDescription()                  { return description; }
    public void setDescription(String d)            { this.description = d; }

    public String getEligibilityRequirements()           { return eligibilityRequirements; }
    public void setEligibilityRequirements(String e)     { this.eligibilityRequirements = e; }

    public List<String> getRequiredActions()        { return requiredActions; }
    public void setRequiredActions(List<String> r)  { this.requiredActions = r; }

    public List<String> getEthnicityBonus()         { return ethnicityBonus; }
    public void setEthnicityBonus(List<String> e)   { this.ethnicityBonus = e; }

    public List<String> getExtracurricularBonus()   { return extracurricularBonus; }
    public void setExtracurricularBonus(List<String> e) { this.extracurricularBonus = e; }

    public Integer getMatchScore()                  { return matchScore; }
    public void setMatchScore(Integer matchScore)   { this.matchScore = matchScore; }

    public List<String> getMatchReasons()           { return matchReasons; }
    public void setMatchReasons(List<String> r)     { this.matchReasons = r; }

    public ScoreBreakdown getScoreBreakdown()            { return scoreBreakdown; }
    public void setScoreBreakdown(ScoreBreakdown sb)     { this.scoreBreakdown = sb; }
}
