package com.prospecto.model;

/**
 * ScoreBreakdown — holds the point breakdown for each scoring category.
 * Mirrors the Python dict: { "gpa": 25, "income": 15, "field": 12, ... }
 */
public class ScoreBreakdown {

    private int gpa;
    private int income;
    private int field;
    private int ethnicity;
    private int extracurricular;

    public ScoreBreakdown() {}

    public ScoreBreakdown(int gpa, int income, int field, int ethnicity, int extracurricular) {
        this.gpa            = gpa;
        this.income         = income;
        this.field          = field;
        this.ethnicity      = ethnicity;
        this.extracurricular = extracurricular;
    }

    public int getGpa()                          { return gpa; }
    public void setGpa(int gpa)                  { this.gpa = gpa; }

    public int getIncome()                       { return income; }
    public void setIncome(int income)            { this.income = income; }

    public int getField()                        { return field; }
    public void setField(int field)              { this.field = field; }

    public int getEthnicity()                    { return ethnicity; }
    public void setEthnicity(int ethnicity)      { this.ethnicity = ethnicity; }

    public int getExtracurricular()              { return extracurricular; }
    public void setExtracurricular(int ec)       { this.extracurricular = ec; }
}
