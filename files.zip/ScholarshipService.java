package com.prospecto.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecto.model.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * ScholarshipService
 *
 * Java port of all Python Flask business logic from app.py.
 * Handles:
 *   - Loading scholarships.json from the classpath
 *   - Calculating match scores (0–100) per student profile
 *   - Filtering and sorting matched scholarships
 *   - OSAP gap calculation
 *   - Filtering scholarships that cover the OSAP gap
 */
@Service
public class ScholarshipService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    // ── Load Scholarships ──────────────────────────────────────────────────
    /**
     * Loads scholarships.json from src/main/resources/scholarships.json.
     * Returns a fresh list each time so modifications (adding scores) don't
     * mutate the cached source data.
     *
     * Equivalent Python: json.load(open("scholarships.json"))
     */
    public List<Scholarship> loadScholarships() throws IOException {
        ClassPathResource resource = new ClassPathResource("scholarships.json");
        try (InputStream is = resource.getInputStream()) {
            return objectMapper.readValue(is, new TypeReference<List<Scholarship>>() {});
        }
    }

    // ── Calculate Match Score (0–100) ──────────────────────────────────────
    /**
     * Calculates a match score from 0–100 for a single scholarship given a
     * student's profile. Returns a MatchResult containing the score, a list
     * of human-readable reasons, and a per-category breakdown.
     *
     * Scoring categories:
     *   GPA              → up to 35 pts
     *   Income           → up to 25 pts
     *   Field of study   → up to 20 pts
     *   Ethnicity bonus  → up to 15 pts
     *   Extracurricular  → up to 10 pts
     *
     * Equivalent Python: calculate_match_score(scholarship, student)
     */
    public MatchResult calculateMatchScore(Scholarship s, StudentProfile student) {

        int score = 0;
        List<String> reasons = new ArrayList<>();
        ScoreBreakdown breakdown = new ScoreBreakdown();

        // Parse student inputs
        double gpa      = student.getGpaDouble();
        double income   = student.getIncomeDouble();
        String ethnicity = student.getEthnicity().toLowerCase();
        String[] interests = Arrays.stream(student.getInterests().split(","))
                                   .map(String::trim)
                                   .map(String::toLowerCase)
                                   .toArray(String[]::new);
        String major    = student.getMajor().toLowerCase();

        // Scholarship criteria (all lowercased for comparison)
        double minGpa        = s.getMinGpa();
        double incomeLimit   = s.getIncomeLimit();
        List<String> fields  = toLower(s.getFieldsOfStudy());
        List<String> ethBonus = toLower(s.getEthnicityBonus());
        List<String> ecBonus  = toLower(s.getExtracurricularBonus());

        // ── 1. GPA Score (up to 35 points) ──────────────────────────────────
        if (gpa >= minGpa) {
            double gpaGap    = gpa - minGpa;
            int gpaPoints    = Math.min(35, 20 + (int)(gpaGap * 15.0));
            score           += gpaPoints;
            breakdown.setGpa(gpaPoints);

            if (gpaGap >= 0.5) {
                reasons.add(String.format(
                    "Your GPA of %.1f exceeds the minimum by %.1f points", gpa, gpaGap));
            } else {
                reasons.add(String.format(
                    "Your GPA of %.1f meets the minimum requirement of %.1f", gpa, minGpa));
            }
        } else {
            // GPA too low → immediately ineligible (score = 0)
            breakdown.setGpa(0);
            reasons.add(String.format(
                "GPA of %.1f is below the minimum required %.1f — not eligible", gpa, minGpa));
            return new MatchResult(0, reasons, breakdown);
        }

        // ── 2. Income Score (up to 25 points) ───────────────────────────────
        if (income <= incomeLimit) {
            int incomePoints;
            if (incomeLimit >= 999999) {
                // No income restriction
                incomePoints = 15;
                reasons.add("No household income restriction for this scholarship");
            } else {
                double ratio = 1.0 - (income / incomeLimit);
                incomePoints = (int)(ratio * 25);
                reasons.add(String.format(
                    "Household income of $%,.0f qualifies (limit: $%,.0f)", income, incomeLimit));
            }
            score += incomePoints;
            breakdown.setIncome(incomePoints);
        } else {
            // Income too high → ineligible
            breakdown.setIncome(0);
            reasons.add(String.format(
                "Household income exceeds the limit of $%,.0f", incomeLimit));
            return new MatchResult(0, reasons, breakdown);
        }

        // ── 3. Field of Study Score (up to 20 points) ───────────────────────
        int fieldPoints;
        if (fields.contains("any")) {
            fieldPoints = 12;
            reasons.add("This scholarship is open to all fields of study");
        } else if (fieldMatchesMajor(fields, major)) {
            fieldPoints = 20;
            reasons.add("Your intended major matches the scholarship's preferred fields");
        } else {
            fieldPoints = 0;
            reasons.add("Your major may not align with preferred fields: " + String.join(", ", fields));
        }
        score += fieldPoints;
        breakdown.setField(fieldPoints);

        // ── 4. Ethnicity Bonus (up to 15 points) ────────────────────────────
        if (!ethBonus.isEmpty()) {
            boolean ethMatch = ethBonus.stream().anyMatch(e -> ethnicity.contains(e))
                || Arrays.stream(ethnicity.split("\\s+")).anyMatch(ethBonus::contains);
            if (ethMatch) {
                score += 15;
                breakdown.setEthnicity(15);
                reasons.add("Your background matches this scholarship's equity focus");
            }
            // else breakdown.ethnicity stays 0
        }

        // ── 5. Extracurricular Bonus (up to 10 points) ──────────────────────
        List<String> ecMatches = ecBonus.stream()
            .filter(ec -> Arrays.stream(interests).anyMatch(interest -> interest.contains(ec)))
            .collect(Collectors.toList());

        if (!ecMatches.isEmpty()) {
            int ecPoints = Math.min(10, ecMatches.size() * 4);
            score += ecPoints;
            breakdown.setExtracurricular(ecPoints);
            String preview = ecMatches.stream().limit(3).collect(Collectors.joining(", "));
            reasons.add("Your interests align with scholarship values: " + preview);
        }

        // Cap at 100
        score = Math.min(100, score);
        return new MatchResult(score, reasons, breakdown);
    }

    // ── Filter & Sort Scholarships for Student ─────────────────────────────
    /**
     * Runs all scholarships through the scoring engine, discards any with
     * score = 0 (ineligible), attaches match data, then sorts by:
     *   1. Match score descending
     *   2. Deadline ascending (nearest deadline first among equals)
     *
     * Equivalent Python: filter_scholarships(student)
     */
    public List<Scholarship> filterScholarships(StudentProfile student) throws IOException {
        List<Scholarship> all = loadScholarships();
        List<Scholarship> results = new ArrayList<>();

        for (Scholarship s : all) {
            MatchResult result = calculateMatchScore(s, student);
            if (result.getScore() > 0) {
                // Attach scoring data to the scholarship object
                s.setMatchScore(result.getScore());
                s.setMatchReasons(result.getReasons());
                s.setScoreBreakdown(result.getBreakdown());
                results.add(s);
            }
        }

        // Sort: highest score first, then nearest deadline
        results.sort(Comparator
            .comparingInt(Scholarship::getMatchScore).reversed()
            .thenComparing(Scholarship::getDeadline));

        return results;
    }

    // ── OSAP Gap Calculation ───────────────────────────────────────────────
    /**
     * Calculates total education cost and the remaining balance after OSAP.
     * remaining = max(0, totalCost - osapLoan)
     *
     * Equivalent Python: calculate_osap_gap(tuition, residence, books, osap_loan)
     */
    public double[] calculateOsapGap(double tuition, double residence,
                                     double books, double osapLoan) {
        double totalCost  = tuition + residence + books;
        double remaining  = Math.max(0, totalCost - osapLoan);
        return new double[]{ totalCost, remaining };
    }

    // ── Filter Scholarships for OSAP Gap ──────────────────────────────────
    /**
     * Returns scholarships that could meaningfully reduce the remaining balance.
     * Includes a scholarship if its amount covers at least 20% of the gap
     * (or covers it entirely). Sorted by highest amount first.
     *
     * Equivalent Python: filter_scholarships_for_gap(remaining_balance)
     */
    public List<Scholarship> filterScholarshipsForGap(double remainingBalance) throws IOException {
        List<Scholarship> all = loadScholarships();

        List<Scholarship> results = all.stream()
            .filter(s -> s.getAmount() >= remainingBalance * 0.20
                      || s.getAmount() >= remainingBalance)
            .sorted(Comparator
                .comparingInt(Scholarship::getAmount).reversed()
                .thenComparing(Scholarship::getDeadline))
            .collect(Collectors.toList());

        return results;
    }

    // ── All Scholarships Sorted by Deadline ────────────────────────────────
    /**
     * Returns every scholarship sorted by deadline (earliest first).
     * Used by the Roadmap page.
     *
     * Equivalent Python: api_all_scholarships()
     */
    public List<Scholarship> getAllScholarshipsByDeadline() throws IOException {
        List<Scholarship> all = loadScholarships();
        all.sort(Comparator.comparing(Scholarship::getDeadline));
        return all;
    }

    // ── Private Helpers ───────────────────────────────────────────────────

    /** Converts a list of strings to lowercase, handles null safely. */
    private List<String> toLower(List<String> list) {
        if (list == null) return Collections.emptyList();
        return list.stream().map(String::toLowerCase).collect(Collectors.toList());
    }

    /**
     * Checks whether any of the scholarship's required fields appear in the
     * student's major string, or vice-versa.
     *
     * Mirrors Python:
     *   any(f in major for f in fields)
     *   or any(m in " ".join(fields) for m in major.split())
     */
    private boolean fieldMatchesMajor(List<String> fields, String major) {
        if (major.isBlank()) return false;
        String fieldsJoined = String.join(" ", fields);

        // Check each field appears in major
        if (fields.stream().anyMatch(major::contains)) return true;

        // Check each word in major appears in the joined fields string
        return Arrays.stream(major.split("\\s+"))
                     .anyMatch(fieldsJoined::contains);
    }
}
