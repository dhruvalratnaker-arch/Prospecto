# ✦ Prospecto — Java Spring Boot

> Canadian Scholarship Matching App — converted from Python Flask to Java Spring Boot.

---

## 🚀 Quick Start

### Requirements
- Java 17+ (`java -version`)
- Maven 3.8+ (`mvn -version`)

### Run the App
```bash
cd prospecto-java
mvn spring-boot:run
```

### Open in Browser
```
http://localhost:8080
```

> **Note:** The Flask version ran on port 5000. The Java version runs on **port 8080**.

---

## 📁 Project Structure

```
prospecto-java/
├── pom.xml                              ← Maven build file (Spring Boot 3.2)
│
└── src/main/
    ├── java/com/prospecto/
    │   ├── ProspectoApplication.java    ← Entry point (@SpringBootApplication)
    │   │
    │   ├── controller/
    │   │   ├── PageController.java      ← Serves 5 HTML pages (GET routes)
    │   │   └── ApiController.java       ← 3 REST API endpoints (POST/GET)
    │   │
    │   ├── service/
    │   │   └── ScholarshipService.java  ← All business logic (ported from app.py)
    │   │
    │   └── model/
    │       ├── Scholarship.java         ← Data model (maps scholarships.json)
    │       ├── StudentProfile.java      ← Request DTO for /api/match
    │       ├── OsapRequest.java         ← Request DTO for /api/osap-gap
    │       ├── MatchResult.java         ← Internal scoring result
    │       ├── MatchResponse.java       ← API response for /api/match
    │       ├── OsapResponse.java        ← API response for /api/osap-gap
    │       └── ScoreBreakdown.java      ← Per-category score breakdown
    │
    └── resources/
        ├── application.properties       ← Spring Boot config
        ├── scholarships.json            ← Scholarship database (12 Canadian scholarships)
        ├── static/
        │   ├── style.css               ← Global stylesheet (unchanged)
        │   └── script.js               ← Frontend JS (unchanged)
        └── templates/
            ├── homepage.html           ← Student form + matches
            ├── osap.html               ← OSAP gap calculator
            ├── roadmap.html            ← Scholarship timeline
            ├── inbox.html              ← Notifications
            └── settings.html          ← Theme + profile
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/match` | Match scholarships to student profile |
| `POST` | `/api/osap-gap` | Calculate tuition gap + gap-covering scholarships |
| `GET`  | `/api/scholarships` | All scholarships sorted by deadline |

---

## 🐍→☕ Python → Java Mapping

| Python (Flask) | Java (Spring Boot) |
|---|---|
| `app.py` | `ScholarshipService.java` + controllers |
| `@app.route("/")` | `@GetMapping("/")` in `PageController` |
| `@app.route("/api/match", methods=["POST"])` | `@PostMapping("/api/match")` in `ApiController` |
| `render_template("homepage.html")` | `return "homepage"` (Thymeleaf) |
| `request.json` | `@RequestBody StudentProfile student` |
| `jsonify({...})` | `ResponseEntity.ok(response)` |
| `json.load(open("scholarships.json"))` | `ObjectMapper.readValue(ClassPathResource)` |
| `scholarships.sort(key=...)` | `list.sort(Comparator.comparing(...))` |
| `dict.get("gpa", 0)` | `student.getGpaDouble()` |
| Flask runs on port 5000 | Spring Boot runs on port 8080 |

---

## 🏗️ Build a Runnable JAR

```bash
mvn clean package
java -jar target/prospecto-2.0.0.jar
```

---

## 🧪 Test the API

```bash
# Match scholarships
curl -X POST http://localhost:8080/api/match \
  -H "Content-Type: application/json" \
  -d '{"gpa":"3.5","income":"65000","ethnicity":"asian","interests":"volunteering, robotics","major":"computer science","tuition":"10000","osap_loan":"7000"}'

# OSAP gap
curl -X POST http://localhost:8080/api/osap-gap \
  -H "Content-Type: application/json" \
  -d '{"tuition":10000,"residence":8000,"books":1500,"osap_loan":8000}'

# All scholarships
curl http://localhost:8080/api/scholarships
```
