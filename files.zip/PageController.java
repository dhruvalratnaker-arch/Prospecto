package com.prospecto.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * PageController
 *
 * Serves the five HTML pages via Thymeleaf view resolution.
 * The HTML files live in src/main/resources/templates/ and contain
 * no Thymeleaf directives — they are served as plain HTML.
 *
 * Equivalent Flask routes:
 *   @app.route("/")        → render_template("homepage.html")
 *   @app.route("/osap")    → render_template("osap.html")
 *   @app.route("/roadmap") → render_template("roadmap.html")
 *   @app.route("/inbox")   → render_template("inbox.html")
 *   @app.route("/settings")→ render_template("settings.html")
 */
@Controller
public class PageController {

    /** Homepage — student profile form + scholarship results */
    @GetMapping("/")
    public String homepage() {
        return "homepage";
    }

    /** OSAP page — tuition gap calculator */
    @GetMapping("/osap")
    public String osap() {
        return "osap";
    }

    /** Roadmap page — scholarship timeline */
    @GetMapping("/roadmap")
    public String roadmap() {
        return "roadmap";
    }

    /** Inbox page — application notifications */
    @GetMapping("/inbox")
    public String inbox() {
        return "inbox";
    }

    /** Settings page — theme toggle + profile edit */
    @GetMapping("/settings")
    public String settings() {
        return "settings";
    }
}
